# @inlog/ds

**Design System INLOG** — Thème PrimeNG et tokens de design pour les applications Angular du groupe INLOG.

---

## Installation

### Option A — Depuis GitHub Packages (recommandé)

Configurer le registry dans `.npmrc` à la racine du projet :

```ini
@inlog:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Puis installer :

```bash
npm install @inlog/ds
```

---

### Option B — Depuis un fichier local (sans registry)

1. Aller dans le dossier du package et le packager :

```bash
cd inlog-ds/
npm pack
# → génère inlog-ds-1.0.0.tgz
```

2. Dans le projet cible, installer le `.tgz` :

```bash
npm install ../chemin/vers/inlog-ds-1.0.0.tgz
# ou depuis un chemin réseau :
npm install \\serveur\partage\inlog-ds-1.0.0.tgz
```

---

### Option C — Lien local pendant le développement

```bash
# Dans le dossier inlog-ds/
npm link

# Dans le projet consommateur
npm link @inlog/ds
```

---

## Utilisation

### 1. Appliquer le thème PrimeNG

Dans `app.config.ts` :

```typescript
import { ApplicationConfig } from '@angular/core';
import { providePrimeNG } from 'primeng/config';
import { GroupTheme } from '@inlog/ds';

export const appConfig: ApplicationConfig = {
  providers: [
    providePrimeNG({
      theme: {
        preset: GroupTheme,
        options: { darkModeSelector: false }
      }
    })
  ]
};
```

C'est tout. Tous les composants PrimeNG utilisent automatiquement les couleurs et styles INLOG.

---

### 2. Utiliser les tokens de design

Les tokens sont utilisables indépendamment de PrimeNG — dans des styles CSS-in-JS, des variables Tailwind, des composants custom, etc.

```typescript
// Import de l'objet complet
import { InlogTokens } from '@inlog/ds';

const primaryColor = InlogTokens.colors.blue[500]; // "#4667e5"
const dangerColor  = InlogTokens.status.danger.DEFAULT; // "#ef4444"

// Import sélectif des tokens
import { colors, primary, status, typography, spacing } from '@inlog/ds';
// ou depuis le sous-chemin dédié
import { colors, primary } from '@inlog/ds/tokens';

// Exemples
colors.blue[500]          // "#4667e5" — Bleu INLOG principal
primary.DEFAULT            // "#4667e5"
primary.hover              // "#3c58c3"
status.success.bg          // "#f0fdf4"
typography.fontSize.base   // "0.875rem"
spacing[4]                 // "1rem"
```

---

### 3. Utiliser les types TypeScript

```typescript
import type { InlogSeverity, InlogSize, InlogVariant } from '@inlog/ds';

@Component({ ... })
export class MyComponent {
  severity: InlogSeverity = 'success'; // 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast'
  size: InlogSize = 'normal';           // 'small' | 'normal' | 'large'
}
```

---

## Mise à jour du thème

Le thème est généré par le **PrimeNG ThemeDesigner**. Pour le mettre à jour :

1. Exporter le nouveau preset depuis [ThemeDesigner](https://designer.primeng.org/)
2. Remplacer les fichiers dans `src/theme/inlog/`
3. Mettre à jour la version dans `package.json`
4. Relancer `npm pack` et redistribuer le `.tgz` (ou pousser sur le registry)

---

## Structure du package

```
@inlog/ds/
├── src/
│   ├── index.ts              ← Point d'entrée public
│   ├── theme/
│   │   ├── group-theme.ts    ← Export du preset PrimeNG
│   │   └── inlog/            ← 91 fichiers de thème (ThemeDesigner)
│   │       ├── index.ts
│   │       ├── base.ts       ← Tokens primitifs + sémantiques
│   │       ├── button.ts
│   │       ├── ...
│   │       └── tooltip.ts
│   └── tokens/
│       └── index.ts          ← Design tokens (couleurs, typo, espacements…)
├── package.json
├── tsconfig.json
└── README.md
```

---

## Compatibilité

| Dépendance      | Version minimale |
|-----------------|-----------------|
| Angular         | ≥ 19.0          |
| PrimeNG         | ≥ 19.0          |
| @primeuix/themes| ≥ 0.7.0         |
| TypeScript      | ≥ 5.4           |

---

## Versions

| Version | Description                          |
|---------|--------------------------------------|
| 1.0.0   | Version initiale — 24 composants     |
